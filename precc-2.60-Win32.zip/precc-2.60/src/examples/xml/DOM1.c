
#include <malloc.h>

          #define boolean int

          typedef char* DOMString;  /* should be unsigned short */

          typedef struct DOMException {
            unsigned short   code;
          } DOMException;
          DOMException * new_DOMException(unsigned short code) {
            DOMException * t = malloc(sizeof(DOMException));
            t->code = code;
            return t;
          }

          // ExceptionCode
          const unsigned short      INDEX_SIZE_ERR     = 1;
          const unsigned short      DOMSTRING_SIZE_ERR = 2;
          const unsigned short      HIERARCHY_REQUEST_ERR = 3;
          const unsigned short      WRONG_DOCUMENT_ERR = 4;
          const unsigned short      INVALID_CHARACTER_ERR = 5;
          const unsigned short      NO_DATA_ALLOWED_ERR = 6;
          const unsigned short      NO_MODIFICATION_ALLOWED_ERR = 7;
          const unsigned short      NOT_FOUND_ERR      = 8;
          const unsigned short      NOT_SUPPORTED_ERR  = 9;
          const unsigned short      INUSE_ATTRIBUTE_ERR = 10;

          typedef struct DOMImplementation {
          boolean (*hasFeature)(struct DOMImplementation *self,
                     DOMString feature, DOMString version);
          } DOMImplementation;
          DOMImplementation * new_DOMImplementation() {
            DOMImplementation * t = malloc(sizeof(DOMImplementation));
            return t;
          }


          typedef struct DocumentFragment {
              struct Node * super;
          } DocumentFragment;
          DocumentFragment * new_DocumentFragment(struct Node * super) {
            DocumentFragment * t = malloc(sizeof(DocumentFragment));
            t->super = super;
            return t;
          }


          typedef struct Document {
            struct Node      * super;
            struct DocumentType     * doctype;
            struct DOMImplementation  *implementation;
            struct Element            *documentElement;
            struct Element            *(*createElement)(struct Document *self, DOMString tagName);
            struct DocumentFragment   *(*createDocumentFragment)(struct Document *self);
            struct Text               *(*createTextNode)(struct Document *self, DOMString data);
            struct Comment            *(*createComment)(struct Document *self, DOMString data);
            struct CDATASection       *(*createCDATASection)(struct Document *self, DOMString data);
            struct ProcessingInstruction *(*createProcessingInstruction)( struct Document *self, DOMString target, DOMString data);
            struct Attr               *(*createAttribute)(struct Document *self, DOMString name);
            struct EntityReference    *(*createEntityReference)(struct Document *self, DOMString name);
            struct NodeList           *(*getElementsByTagName)(struct Document *self, DOMString tagname);
          } Document;
          Document * new_Document(struct Node * super,struct DocumentType * doctype,struct DOMImplementation *implementation, struct Element *documentElement) {
            Document * t = malloc(sizeof(Document));
            t->super = super;
            t->doctype = doctype;
            t->implementation = implementation;
            t->documentElement = documentElement;
            return t;
          }


            // NodeType
            const unsigned short      ELEMENT_NODE       = 1;
            const unsigned short      ATTRIBUTE_NODE     = 2;
            const unsigned short      TEXT_NODE          = 3;
            const unsigned short      CDATA_SECTION_NODE = 4;
            const unsigned short      ENTITY_REFERENCE_NODE = 5;
            const unsigned short      ENTITY_NODE        = 6;
            const unsigned short      PROCESSING_INSTRUCTION_NODE = 7;
            const unsigned short      COMMENT_NODE       = 8;
            const unsigned short      DOCUMENT_NODE      = 9;
            const unsigned short      DOCUMENT_TYPE_NODE = 10;
            const unsigned short      DOCUMENT_FRAGMENT_NODE = 11;
            const unsigned short      NOTATION_NODE      = 12;

          typedef struct Node {
            DOMString      nodeName;
            DOMString      nodeValue;
            unsigned short nodeType;
            struct Node          *parentNode;
            struct NodeList      *childNodes;
            struct Node          *firstChild;
            struct Node          *lastChild;
            struct Node          *previousSibling;
            struct Node          *nextSibling;
            struct NamedNodeMap  *attributes;
            struct Document      *ownerDocument;
            struct Node          *(*insertBefore)(struct Node *self,struct Node *newChild, struct Node *refChild);
            struct Node          *(*replaceChild)(struct Node *self,struct Node *newChild, struct Node *oldChild);
            struct Node          *(*removeChild)(struct Node *self,struct Node *oldChild);
            struct Node          *(*appendChild)(struct Node *self,struct Node *newChild);
            boolean               (*hasChildNodes)(struct Node *self);
            struct Node          *(*cloneNode)(struct Node *self,boolean deep);
          } Node;
          Node * new_Node(DOMString nodeName, DOMString nodeValue, unsigned short nodeType, struct Node *parentNode,
                      struct NodeList *childNodes, struct Node  *firstChild, struct Node  *lastChild,
                      struct Node  *previousSibling, struct Node  *nextSibling, struct NamedNodeMap  *attributes,
                      struct Document *ownerDocument) {
            Node * t = malloc(sizeof(Node));
            t->nodeName = nodeName;
            t->nodeValue = nodeValue;
            t->nodeType = nodeType;
            t->parentNode = parentNode;
            t->childNodes = childNodes;
            t->firstChild = firstChild;
            t->lastChild = lastChild;
            t->previousSibling = previousSibling;
            t->nextSibling = nextSibling;
            t->attributes = attributes;
            t->ownerDocument = ownerDocument;
            return t;
          }


          typedef struct NodeList {
            struct Node     *(*item)(struct NodeList * self,unsigned long index);
            unsigned long   length;
          } NodeList;
          NodeList * new_NodeList(unsigned long length) {
            NodeList * t = malloc(sizeof(NodeList));
            t->length = length;
            return t;
          }

          typedef struct NamedNodeMap {
            struct Node  *(*getNamedItem)(struct NamedNodeMap *self,DOMString name);
            struct Node  *(*setNamedItem)(struct NamedNodeMap *self,struct Node *arg);
            struct Node  *(*removeNamedItem)(struct NamedNodeMap *self,DOMString name);
            struct Node  *(*item)(struct NamedNodeMap *self,unsigned long index);
            unsigned long        length;
          } NamedNodeMap;
          NamedNodeMap * new_NamedNodeMap(unsigned long length) {
            NamedNodeMap * t = malloc(sizeof(NamedNodeMap));
            t->length = length;
            return t;
          }

          typedef struct CharacterData {
            Node    * super;
            DOMString            data;
            unsigned long        length;
            DOMString  (*substringData)(struct CharacterData * self,unsigned long offset, unsigned long count);
            void   (*appendData)(struct CharacterData * self,DOMString arg);
            void   (*insertData)(struct CharacterData * self,unsigned long offset, DOMString arg);
            void   (*deleteData)(struct CharacterData * self,unsigned long offset, unsigned long count);
            void   (*replaceData)(struct CharacterData * self,unsigned long offset, unsigned long count, DOMString arg);
          } CharacterData;
          CharacterData * new_CharacterData(Node * super, DOMString data, unsigned long length) {
            CharacterData * t = malloc(sizeof(CharacterData));
            t->super  = super;
            t->data   = data;
            t->length = length;
            return t;
          }


          typedef struct Attr {
            Node * super;
            DOMString            name;
            boolean              specified;
            DOMString            value;
          } Attr;
          Attr * new_Attr(Node * super, DOMString name, boolean specified, DOMString value) {
            Attr * t = malloc(sizeof(Attr));
            t->super  = super;
            t->name   = name;
            t->specified   = specified;
            t->value  = value;
            return t;
          }


          typedef struct Element {
            Node * super;
            DOMString    tagName;
            DOMString    (*getAttribute)(struct Element *self,DOMString name);
            void         (*setAttribute)(struct Element *self,DOMString name, DOMString value);
            void         (*removeAttribute)(struct Element *self,DOMString name);
            struct Attr         *(*getAttributeNode)(struct Element *self,DOMString name);
            struct Attr         *(*setAttributeNode)(struct Element *self,struct Attr newAttr);
            struct Attr         *(*removeAttributeNode)(struct Element *self,struct Attr oldAttr);
            struct NodeList     *(*getElementsByTagName)(struct Element *self,DOMString name);
            void         (*normalize)(struct Element *self);
          } Element;
          Element * new_Element(Node * super, DOMString tagName) {
            Element * t = malloc(sizeof(Element));
            t->super  = super;
            t->tagName   = tagName;
            return t;
          }


          typedef struct Text{
            CharacterData * super;
            struct Text  *(*splitText)(struct Text *self,unsigned long offset);
          } Text;
          Text * new_Text(CharacterData * super) {
            Text * t = malloc(sizeof(Text));
            t->super  = super;
            return t;
          }

          typedef struct Comment {
            struct CharacterData * super;
          } Comment;
          Comment * new_Comment(CharacterData * super) {
            Comment * t = malloc(sizeof(Comment));
            t->super  = super;
            return t;
          }

          typedef struct CDATASection {
            struct Text * super;
          } CDATASection;
          CDATASection * new_CDATASection(Text * super) {
            CDATASection * t = malloc(sizeof(CDATASection));
            t->super  = super;
            return t;
          }

          typedef struct DocumentType {
            struct Node * super;
            DOMString            name;
            struct NamedNodeMap         *entities;
            struct NamedNodeMap         *notations;
          } DocumentType;
          DocumentType * new_DocumentType(Node * super,DOMString name,struct NamedNodeMap *entities, struct NamedNodeMap *notations) {
            DocumentType * t = malloc(sizeof(DocumentType));
            t->super  = super;
            t->name  = name;
            t->entities  = entities;
            t->notations  = notations;
            return t;
          }

          typedef struct Notation {
            struct Node * super;
            DOMString            publicId;
            DOMString            systemId;
          } Notation;
          Notation * new_Notation(Node * super,DOMString publicId,DOMString systemId) {
            Notation * t = malloc(sizeof(Notation));
            t->super  = super;
            t->publicId  = publicId;
            t->systemId  = systemId;
            return t;
          }


          typedef struct Entity {
            Node * super;
            DOMString            publicId;
            DOMString            systemId;
            DOMString            notationName;
          } Entity;
          Entity * new_Entity(Node * super,DOMString publicId,DOMString systemId,DOMString notationName) {
            Entity * t = malloc(sizeof(Entity));
            t->super  = super;
            t->publicId  = publicId;
            t->systemId  = systemId;
            t->notationName  = notationName;
            return t;
          }

          typedef struct EntityReference {
            struct Node * super;
          } EntityReference;
          EntityReference * new_EntityReference(Node * super) {
            EntityReference * t = malloc(sizeof(EntityReference));
            t->super  = super;
            return t;
          }


          typedef struct ProcessingInstruction {
            struct Node * super;
            DOMString            target;
            DOMString            data;
          } ProcessingInstruction;
          ProcessingInstruction * new_ProcessingInstruction(Node * super,DOMString target,DOMString data) {
            ProcessingInstruction * t = malloc(sizeof(ProcessingInstruction));
            t->super  = super;
            t->target  = target;
            t->data  = data;
            return t;
          }

