#ifndef P_CONFIG_H
#define P_CONFIG_H

@TOP@

/* define if you have an optimization bug present in turbo C 3.0 */
#undef C_COMPILE_BUG_1

/* define if your C stack has &y < &x inside a function foo(x,y) */
#undef C_DESCENDING_STACK

/* define if your C compiler passes structs by reference not by value */
#undef C_STRUCT_REFERENCE

/* define if your C compiler accepts nonconstant variable initializers */
#define C_NONCONST_INITIALIZERS 1

/* define if your va_start builtin won't always repeat successfully */
#undef C_VASTART_REPEAT_BROKEN

/* define if the platform is DOS-based */
#undef DOS

/* define if stdio.h declares getchar as a function as well as a macro */
#define HAVE_DECL_GETCHAR 1

/* Define if the C compiler understands __cdecl.  */
#undef C_HAS_CDECL_MODIFIER      

@BOTTOM@

#endif
