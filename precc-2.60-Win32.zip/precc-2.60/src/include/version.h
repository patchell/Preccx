# define __PRECC__ 2,59
# ifndef __DATE__
#   define __DATE__ "Tue Jun 26 16:53:15 CEST 2007"
# endif
